# MCW policy-only release

기준 저장소 커밋: 8eefd3af670e30604f1515096bdd8c0373f3fd63 (시원님 mcw).
이 ZIP은 전체 저장소나 Python 환경이 아니라 코드 변경·모델·평가 근거 묶음입니다.
기준 저장소 루트에 압축을 푼 뒤 docs/review/mcw-policy-only-20261119.md의 명령을 실행하세요.
최종 모델: results/mcw_policy_only/road-balanced27-heldout80/evaluated_model.pt
최종 결과: 같은 폴더 eval.json. 검사 결과: verification.json.
경로는 ZIP 안에서 저장소 루트 기준입니다. 다른 수정사항이 있는 파일은 덮어쓰기 전에 확인하세요.
manifest의 코드/시나리오 해시와 SHA256SUMS.json으로 내용을 대조할 수 있습니다.
