"""Package the frozen model and its evidence after independent evaluation."""
import collections
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'results/mcw_policy_only'
FINAL = BASE/'road-balanced27-heldout80'


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    final = read(FINAL/'eval.json')
    development = read(BASE/'road-balanced27-dev80/eval.json')
    audit = read(FINAL/'verification.json')
    assert final['status']=='complete' and final['primary_goal_confirmed']
    assert audit['contract_tests_passed'] and audit['trained_and_evaluated_weights_identical']
    counts=collections.Counter(r['outcome'] for r in final['rows'])
    assert sum(counts.values())==80
    route_table='\n'.join(
        f"| {r['route'][-2:]} | {r['counts'].get('arrival',0)}/5 | {r['counts'].get('collision',0)} | {r['counts'].get('timeout',0)} |"
        for r in final['per_route'])
    failures='\n'.join(
        f"- 경로 {r['route'][-2:]}, 시드 `{r['seed']}`: {r['outcome']}, {r['seconds']:.1f}초, 도로 `{r['edge']}`."
        for r in final['rows'] if r['outcome']!='arrival') or '- 없음.'
    lineage=[('road-none-23','model.pt'),('road-none-23b','model-32768.pt'),
        ('road-memory-23','model.pt'),('road-geometry-23','model.pt'),('road-goal-23','model.pt'),
        ('road-traffic-features-23','model.pt'),('road-traffic-balanced-24','model.pt'),
        ('road-joint-25','model.pt'),('road-recovery-26','model.pt'),('road-balanced-27','model.pt')]
    steps={name:json.loads((BASE/name/'train.jsonl').read_text().splitlines()[-1])['step'] for name,_ in lineage}
    assert sum(steps.values())==505856
    lineage_table='\n'.join(f'| `{name}` | {steps[name]:,} | `{model}` |' for name,model in lineage)
    report=f'''# 시원님 MCW 기반: 안전게이트·차로 지정 없는 PPO

최종 모델: `road-balanced-27`. 개발 평가 후 가중치를 고정하고 새로운 교통 시드로 80회 독립 평가했다. **완주 {counts['arrival']}/80 ({100*final['arrival_rate']:.2f}%), AV 충돌 {counts['collision']}/80 ({100*final['collision_rate']:.2f}%), 시간초과 {counts['timeout']}/80**. 기존 MCW 목표인 **전체 완주율 ≥95%, 전체 충돌률 <5%**를 이번 평가에서 충족했다. 모든 교통 상황에서의 안전을 보장하는 결과는 아니다.

## 평가 결과와 범위

| 평가 | 시행 | 완주 | AV 충돌 | 시간초과 |
|---|---:|---:|---:|---:|
| 시원님 최신 MCW + 기존 가중치, 안전게이트·차로 안내 유지 | 80 | 79 (98.75%) | 0 | 1 |
| 새 모델 개발 평가, 게이트·차로 안내 제거 | 80 | {development['totals'].get('arrival',0)} (100%) | 0 | 0 |
| **새 모델 독립 평가, 게이트·차로 안내 제거** | **80** | **{counts['arrival']} ({100*final['arrival_rate']:.2f}%)** | **{counts['collision']} ({100*final['collision_rate']:.2f}%)** | **{counts['timeout']}** |

원본은 40001번대, 개발은 50001번대, 독립 평가는 60001번대 시드를 사용했다. 각 반복의 시드는 `기준값 + 100×반복번호 + 경로번호-1`이고 반복번호는 0~4이다. 학습은 110000~119999에서 추출했다. 원본과 새 모델의 지도·교통 파일·설정 해시는 동일하지만 시드가 다르므로 표만으로 성능 차이의 통계적 유의성을 주장하지 않는다. 독립 평가 시드는 학습·모델 선택에 사용하지 않았고 평가 도중 가중치를 변경하지 않았다.

완주율은 완주 횟수/전체 시도 수, 충돌률은 AV 충돌 에피소드 수/전체 시도 수다. 시간초과·투입 실패·비정상 종료도 분모에서 제외하지 않는다. 실제 SUMO 도착 이벤트와 마지막 목적 도로를 확인하며 충돌이 동시에 있으면 충돌을 우선한다. 순간이동으로 완주시키지 않는다.

| 경로 | 독립 평가 완주 | 충돌 | 시간초과 |
|---|---:|---:|---:|
{route_table}

전체 80회 기준 목표와 경로별 5회 성적은 구분해야 한다. 실패 원자료:

{failures}

2번의 두 시간초과는 `169929488#0_0`에서 정지한 채 차로 유지를 선택한 사례다. 11번은 71.4초에 충돌했고 직전 71.2초에는 `206426298_0`에서 약 16.21m/s로 주행하며 강한 감속과 차로 유지를 출력했다. 전방 간격·TTC 위험값이 이미 약 0.98이어서 감속했지만 충돌을 피하지 못했다. 이를 게이트로 숨기거나 성공으로 바꾸지 않았다. 개선 여지는 2번의 정지 후 경로 복귀와 11번의 더 이른 속도 조절이다.

실패 직전 2초의 관측·행동은 `road-balanced27-heldout80/failures.jsonl`, 전체 결과는 같은 폴더의 `eval.json`에 있다. `trace.jsonl`의 주변 차량 디버그 정보는 분석용이며 정책 입력으로 사용하지 않는다.

## 어떤 코드를 바꿨나

- 출발 코드: 시원님 `origin/mcw`, 커밋 `8eefd3af670e30604f1515096bdd8c0373f3fd63` (2026-11-18).
- 출발 가중치: 시원님 `stage3_high_v5_b/best_model.pt`. 개인 `gap-lane-22` 모델은 사용하지 않았다.
- 작업 브랜치: `codex/siwon-policy-only`. 기존 공용 MCW 파일을 덮어쓰지 않고 새 환경·러너·검증기를 추가했다.

| 항목 | 시원님 원본 | 최종 변경 |
|---|---|---|
| 안전게이트 | 위험한 변경을 취소 | 비활성화; 게이트 함수가 호출되면 오류 발생 |
| 내비게이션 | 권장 차로·차로 마스크·경로에 맞는 차로 연결성 | 현재/다음/그다음 도로 ID와 다음 두 도로 입구의 중심 위치 |
| 차로 연결성 | 목적 도로로 연결되는 차로인지 제공 | 어느 도로든 물리적 연결이 있는지만 제공 |
| 차로 준비 보상 | 권장 차로에 도달하면 보상 | 제거; 도로 진행·도로 입구에 가까워지는 정도에 보상 |
| 주변 차량 관측 | MCW 경계·합류부 관측 | 유지하고 겹친 차량 및 출발 직후 인접 차량 누락 보완 |
| 추가 관측 | 기존 47차원 | 도로 ID, 차로·거리, 최근 행동·정지시간, 주변 간격·접근속도 등을 포함해 총 251차원 |
| PPO | 기존 모델 | 동일 모델에서 추가 학습; 마지막 단계는 전체 운전 정책을 학습 |

도로 중심 위치는 해당 도로의 **모든 차로 시작점 평균**이다. 특정 차로를 고르거나 차로 정답을 계산하지 않는다. 도로 ID를 포함하므로 이 결과의 적용 범위는 현재 고정 지도와 16개 경로이며, 처음 보는 지도에 대한 일반화 결과가 아니다.

251차원은 센서가 251개라는 뜻이 아니다. 도로 ID의 one-hot 표현과 기존 주변 차량 정보의 정규화 표현, 사용하지 않는 0값 슬롯도 포함한다. 관측 인덱스는 `manifest.json`의 `observation_schema_half_open`에 저장했다. 기존 차로 안내 입력 31~33·37~46은 0이고 대응 입력 가중치도 0임을 검사했다.

초기 가중치는 과거에 게이트·차로 안내가 있는 환경에서 학습된 모델이다. **이번 추가 학습과 평가는 그 기능을 제거했다.** 처음부터 도움 없이 학습한 모델이라고 표현하면 안 된다. 새 교사 행동·모방학습·수동 차로 정답·실패 시 강제 복구는 사용하지 않았다.

## 최종 보상

위험한 행동에는 학습 중 감점을 주지만, 실행 중 해당 행동을 취소하거나 다른 행동으로 바꾸지 않는다.

| 보상 항목 | 최종 설정 |
|---|---|
| 실제 주행 속도 | 스텝당 `+0.035 × 속도/vmax` |
| 실제 다음 도로 진입 | 진행 도로당 `+0.6` |
| 다음 도로 입구에 가까워짐 | 거리 감소량 × `0.015`; 거리 200m에서 제한 |
| 그다음 도로 입구에 가까워짐 | 거리 감소량 × `0.005`; 거리 300m에서 제한 |
| 완주 / 충돌 / 시간초과·기타 실패 | `+20 / -30 / -20` |
| 전방 간격 부족 | 연속적인 간격 부족 정도 × `-0.08` |
| 전방 간격 부족 상태에서 양의 가속 | 행동 전 간격 부족 정도 × 양의 가속 출력 × `-0.1` |
| 인접 앞뒤 간격이 부족한 방향으로 변경 명령 | 해당 방향의 최대 간격 부족 정도 × `-0.3` |
| 물리적으로 실행할 수 없는 변경 명령 | `-0.2` |
| 실제 차로 변경 / 2초 이내 반대 방향 재변경 | `-0.01 / 추가 -0.2` |
| 앞이 비어 있는데 저속·정지 | 앞차가 없거나 25m 초과, 속도 3m/s 미만이면 최대 `-0.08/스텝` |
| 시간 비용 | `-0.002/스텝` |

도로 목표가 바뀌는 스텝에는 거리 감소 보상을 주지 않는다. 위험값은 거리·속도에서 계산한 연속적인 특징이며 통계적으로 보정된 충돌 확률이 아니다. 정지 벌점이나 불가능한 명령 벌점도 가감속·변경을 강제하지 않는다.

## PPO 학습과 평가 조건

PPO의 기본 목적함수는 유지했다. 최종 단계의 정책/가치 학습률은 각각 `0.00002/0.0002`, gamma `0.995`, GAE lambda `0.95`, clip `0.15`, rollout `2048`, epoch `5`, minibatch `256`, 은닉층 `256×256`, 가치 손실 계수 `0.05`, 차로 엔트로피 계수 `0.001`이다. 가속은 연속 출력이고 차로 행동은 좌/유지/우 범주형 출력이다.

가치평가 손실은 공유 운전 특징으로 역전파하지 않게 분리했고, 운전 정책은 PPO 정책 손실로 학습한다. 제한시간 실패에서도 GAE를 끊어 다음 에피소드의 가치가 이전 에피소드에 섞이지 않게 했다. 최종 단계는 16개 경로를 고르게 학습하고, 에피소드마다 15% 확률로 무교통 경로 주행을 복습했다. 이는 **학습 전용**이며 최종 평가는 전부 혼잡 교통이다. 최종 단계의 혼잡 교통 학습 종료는 153완주·23충돌, 무교통은 37완주이며, 이 혼합 학습 성적을 평가 성적으로 제시하지 않는다.

선정된 모델 계보의 추가 학습량은 **505,856스텝**이다. 매 단계 optimizer를 새로 시작했다. 탈락한 별도 후보의 스텝은 이 합계에 넣지 않았다.

| 실행 | 추가 스텝 | 계승한 체크포인트 |
|---|---:|---|
{lineage_table}

관측이 223→227→231→251차원으로 확장되고 보상이 바뀐 개발 과정이다. 현재 명령 하나로 이 과거 전체 과정을 그대로 재현했다는 뜻은 아니다. 저장된 마지막 단계 입력 모델·소스·조건으로 마지막 학습 단계와 최종 평가를 재실행할 수 있다. 일부 초기 실행은 소스 스냅샷 없이 해시만 남아 있으므로 전체 계보의 완전한 재학습 재현은 주장하지 않는다.

| 조건 | 고정값 |
|---|---|
| 교통 | MCW `high_real_ratio`, 15,000대/시간 투입 수요 |
| 차종 구성 | 승용 77%·소형화물 18%·대형화물 4%·버스 1% |
| 배경 차량 선행 주행 | 300스텝 × 0.2초 = 60초 |
| AV 출발 | 원본과 동일한 `best` 차로·`max` 속도 |
| 최대 속도 / 가감속 한계 | 27.78m/s / 5.4m/s² |
| 관측 | 원본 50m 범위와 MCW 경계·합류 관측, 노이즈 없음 |
| 제한시간 | 학습 240초, 평가 600초 |
| 평가 행동 | 결정적 PPO 출력, 가속 평균·차로 최대 확률 |
| 시뮬레이터 | SUMO/libsumo 1.27.1, 0.2초 간격 |
| 실행 환경 | Python 3.10.2, PyTorch 2.14.0+cpu, NumPy 2.2.6, torch threads 1 |

15,000은 실제 1시간에 무조건 모두 투입됐다는 값이 아니라 수요 설정이다. 진입 정체에 따라 실제 투입은 지연될 수 있다. 지도/교통을 쉽게 바꾸거나 감지 범위를 넓혀 목표를 맞추지 않았다. 100~200m 관측·거리별 노이즈는 이번 작업에 포함하지 않았다.

`speedMode=0`, `laneChangeMode=0`을 확인한다. 기존 실선·존재하지 않는 차로·교차로 내부 변경 제한과 물리적 속도 범위는 유지한다. 이것을 SUMO의 모든 물리·교통 규칙 제거라고 표현하지 않는다. 충돌 검사 활성화, 충돌 시 remove, 순간이동 비활성화 상태이다.

## 중간 실패도 보존

| 개발 후보 | 완주 | 충돌 | 시간초과 | 판단 |
|---|---:|---:|---:|---|
| 도로 주행 학습 후 혼잡 교통 80회 | 71 | 9 | 0 | 목표 미달 |
| 위험 입력만 균등 학습, 16회 | 13 | 0 | 3 | 정지 문제로 미채택 |
| 전체 정책 + 무교통 복습, 80회 | 74 | 1 | 5 | 목표 미달 |
| 불가능한 변경 명령 벌점 강화, 80회 | 75 | 1 | 4 | 목표 미달 |
| 최종 균등 재학습, 개발 80회 | 80 | 0 | 0 | 가중치 고정 후 독립 평가 |

초기에는 위험이 관측에 있어도 끼어들어 충돌했고, 위험 벌점만 강조한 후보는 도로 끝에서 멈췄다. 마지막 단계에서는 전체 정책이 경로 진행과 안전 사이의 선택을 다시 학습하게 했다. 이러한 여러 변경의 개별 기여도를 분리한 완전한 ablation 실험은 아니다.

게이트만 제거한 기존 모델 실험은 39회에서 중단됐다(27완주·11충돌·1시간초과). 첫 16경로는 12완주·3충돌·1시간초과다. 이를 완료된 80회 실험으로 표시하지 않는다. 시원님 11월16일 보고서의 78/80·2충돌과 이번 원본 재현 79/80·0충돌도 구분한다. 이번에는 11월18일 합류 관측 수정이 포함된 코드를 사용했다.

## 검증과 실행

검사 4개 통과: 차로 안내 함수 호출 금지, 제거한 관측 슬롯 확인, 관측 캐시 일치, 위험한 고정 명령의 실제 충돌, 선택 가능한 부분 학습 모드의 가중치 제한을 검사했다. 체크포인트 감사에서 **마지막 학습과 평가 가중치 동일, 원본과 시나리오 동일, 런타임 소스 해시 일치, 전체 PPO 정책 가중치 변경, 제거한 차로 안내 가중치 0**을 확인했다. 상세는 `road-balanced27-heldout80/verification.json`이다.

기준 MCW 저장소에서 배포 ZIP을 저장소 루트에 풀고 실행한다. 필요한 Python 패키지는 저장소 `requirements.txt`를 사용하며 같은 결과를 비교하려면 위 버전과 SUMO 1.27.1/libsumo를 맞춘다. 아래 명령은 **최종 모델을 명시**한다. `--resume`을 생략하면 초기 시원님 가중치를 사용한다.

```powershell
python -X utf8 -m utils.mcw_policy_only --stage high_real_ratio --resume results/mcw_policy_only/road-balanced27-heldout80/evaluated_model.pt --out results/mcw_policy_only/replay-final-80 --eval-seed 60001 --episodes 5 --split heldout --trace --future-goal-coef 0.005 --acceleration-risk-penalty 0.1 --invalid-command-penalty 0.2
```

이는 이미 공개된 최종 80조건의 **재현** 명령이며 새로운 독립 증거를 추가하는 것은 아니다. 결과 폴더가 이미 존재하면 다른 `--out`을 사용한다. 이 러너는 headless 평가용이며 `.sumocfg`만 GUI에서 열면 학습된 AV 정책이 자동 실행되지 않는다.

마지막 65,536스텝 학습 재실행:

```powershell
python -X utf8 -m utils.mcw_policy_only --train --stage high_real_ratio --resume results/mcw_policy_only/road-recovery-26/model.pt --out results/mcw_policy_only/retrain-final --steps 65536 --seed 27 --lr 0.00002 --critic-lr-mult 10 --value-coef 0.05 --entropy 0.001 --empty-fraction 0.15 --detach-value --future-goal-coef 0.005 --acceleration-risk-penalty 0.1 --invalid-command-penalty 0.2
```

체크포인트 검증:

```powershell
python -X utf8 -m utils.audit_mcw_policy_only --warmstart results/mcw_policy_only/road-recovery-26/model.pt --trained-checkpoint results/mcw_policy_only/road-balanced-27/model.pt --checkpoint results/mcw_policy_only/road-balanced27-heldout80/evaluated_model.pt --manifest results/mcw_policy_only/road-balanced-27/manifest.json --evaluation-manifest results/mcw_policy_only/road-balanced27-heldout80/manifest.json --baseline-manifest results/mcw_policy_only/original-80/manifest.json --out results/mcw_policy_only/replay-verification.json
```

최종 평가 모델 SHA-256: `{audit['evaluated_checkpoint_sha256']}`.
'''
    (ROOT/'docs/review/mcw-policy-only-20261119.md').write_text(report,encoding='utf8')
    selected={ROOT/p for p in ('env/mcw_policy_only.py','utils/mcw_policy_only.py',
        'utils/audit_mcw_policy_only.py','tests/test_mcw_policy_only.py',
        'docs/review/mcw-policy-only-20261119.md')}
    # Keep experiment evidence, but avoid packing every intermediate checkpoint.
    eval_dirs=['original-80','no-gate-80','road-goal-dev80','road-traffic-balanced-dev16',
        'road-joint-dev80','road-recovery-dev80','road-balanced27-dev16',
        'road-balanced27-dev80','road-balanced27-heldout80']
    for name in eval_dirs:
        for path in (BASE/name).rglob('*'):
            if path.is_file() and path.suffix in ('.json','.jsonl','.py'):
                selected.add(path)
    for name,model in lineage:
        selected.add(BASE/name/model)
        for path in (BASE/name).rglob('*'):
            if path.is_file() and path.suffix in ('.json','.jsonl','.py'):
                selected.add(path)
    selected.add(FINAL/'evaluated_model.pt')
    selected.add(ROOT/'results/mcw_runs/stage3_high_v5_b/best_model.pt')
    for stage in ('none','high_real_ratio'):
        selected.update(p for p in (BASE/'scenarios'/stage).iterdir() if p.is_file())
    selected.add(Path(__file__).resolve())
    readme=BASE/'RELEASE_README.md'
    readme.write_text('''# MCW policy-only release

기준 저장소 커밋: 8eefd3af670e30604f1515096bdd8c0373f3fd63 (시원님 mcw).
이 ZIP은 전체 저장소나 Python 환경이 아니라 코드 변경·모델·평가 근거 묶음입니다.
기준 저장소 루트에 압축을 푼 뒤 docs/review/mcw-policy-only-20261119.md의 명령을 실행하세요.
최종 모델: results/mcw_policy_only/road-balanced27-heldout80/evaluated_model.pt
최종 결과: 같은 폴더 eval.json. 검사 결과: verification.json.
경로는 ZIP 안에서 저장소 루트 기준입니다. 다른 수정사항이 있는 파일은 덮어쓰기 전에 확인하세요.
manifest의 코드/시나리오 해시와 SHA256SUMS.json으로 내용을 대조할 수 있습니다.
''',encoding='utf8')
    selected.add(readme)
    hashes={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(selected)}
    archive=BASE/'mcw-policy-only-release-20261120.zip'
    assert not archive.exists(), 'Preserve the existing release; choose a new version'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(selected):
            z.write(p,p.relative_to(ROOT).as_posix())
        z.writestr('SHA256SUMS.json',json.dumps(hashes,indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name,expected in hashes.items():
            assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
    output=dict(archive=str(archive),files=len(selected),bytes=archive.stat().st_size,
        sha256=sha(archive),added_training_steps=sum(steps.values()),
        independent_evaluation_counts=dict(counts),archive_integrity_verified=True)
    (BASE/'release_summary.json').write_text(json.dumps(output,indent=2),encoding='utf8')
    print(json.dumps(output,indent=2))


if __name__=='__main__':
    main()
