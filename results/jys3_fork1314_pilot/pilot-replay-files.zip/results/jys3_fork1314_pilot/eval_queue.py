import sys,time,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from itertools import product
root=Path.cwd()
base=root/'results/jys3_fork1314_pilot'
jobs=[(s,k,m) for m in (0,16384,32768,50000) for k in ('screen','holdout') if k=='screen' or m in (0,50000) for s in (11,22,33)]
def run(s,k,m):
    dest=base/f'seed{s}'/f'{k}_{m}.json'
    if dest.exists():return
    with (base/f'{k}_{s}_{m}.err').open('w') as error:
        subprocess.run([sys.executable,'-m','utils.jys3_fork1314_pilot',k,str(s),str(m)],cwd=root,stderr=error,check=True)
with ThreadPoolExecutor(3) as pool:
    pending=list(jobs);futures=[]
    while pending or futures:
        for future in futures[:]:
            if future.done():future.result();futures.remove(future)
        for job in pending[:]:
            s,k,m=job
            if len(futures)>=3:break
            if (base/f'seed{s}'/f'policy_{m}.pt').exists():
                pending.remove(job);futures.append(pool.submit(run,*job))
        time.sleep(2)

