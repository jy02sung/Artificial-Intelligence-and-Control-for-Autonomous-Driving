import hashlib,json,shutil
from pathlib import Path
base=Path(__file__).resolve().parent
def read(f):
    return [json.loads(x) for x in f.read_text().splitlines()]
for seed in (11,22,33):
    old=base/f'partial{seed}_before_trace_fix'
    new=base/f'seed{seed}'
    f=new/'initial.json'
    if not f.exists():continue
    assert json.loads(f.read_bytes())==json.loads((old/'initial.json').read_bytes())
    for f in old.glob('*.json'):
        if f.name.startswith(('screen_','holdout_')):
            dest=new/f.name
            weights='policy_'+f.stem.split('_')[-1]+'.pt'
            if (new/weights).exists():
                assert (new/weights).read_bytes()==(old/weights).read_bytes(),(seed,weights)
                if not dest.exists():shutil.copyfile(f,dest)
    a=read(old/'episodes.jsonl')
    b=read(new/'episodes.jsonl')
    for x,y in zip(a,b):
        assert all(v==y[k] for k,v in x.items()),(x,y)
    if len(b)>len(a):
        print('recovered',seed,b[len(a)])
    else:
        print('matching',seed,min(len(a),len(b)))

