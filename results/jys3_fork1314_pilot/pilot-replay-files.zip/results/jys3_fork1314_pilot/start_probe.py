from pathlib import Path
from tempfile import TemporaryDirectory
import json,sys,os,time
root=Path.cwd();sys.path.insert(0,str(root))
from utils.jys3_fork1314_pilot import Pilot,panel,ROOT,j,pure,write
import numpy as np
j.torch.set_num_threads(1)
with TemporaryDirectory() as td:
    env=Pilot(Path(td),11,False)
    states=[]; rows=[]
    try:
        for case in panel('holdout'):
            obs,_=env.reset(case)
            rows.append(list(case)); states.append(obs.copy())
    finally:env.env.close()
for a,b in zip(states[::2],states[1::2]):assert np.flatnonzero(a!=b).tolist()==[34]
x=j.torch.as_tensor(np.stack(states),dtype=j.torch.float32)
for seed in [11,22,33]:
    model=pure.agent(seed)
    for mark in (0,50000):
        p=ROOT/f'seed{seed}'/f'policy_{mark}.pt'
        while not p.exists():time.sleep(2)
        model.policy.load_state_dict(j.torch.load(p,weights_only=True))
        model.policy.eval()
        with j.torch.no_grad():
            probs=j.torch.softmax(model.policy(x)[2],dim=-1).numpy()
        assert tuple(model.policy.LANE_CMDS)==(1.,0.,-1.)
        write(ROOT/f'seed{seed}'/f'start_prob_{mark}.json',[dict(route=c[0],lane=c[1],traffic_seed=c[2],left=float(v[0]),keep=float(v[1]),right=float(v[2])) for c,v in zip(rows,probs)])

